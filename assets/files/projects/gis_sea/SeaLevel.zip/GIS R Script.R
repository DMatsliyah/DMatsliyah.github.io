############ GIS Data project ############

#####Load packages#####
require(ggplot2)
require(matrixStats)
library(dygraphs)
library(xts)          # To make the convertion data-frame / xts format
library(tidyverse)
library(lubridate)
library(htmlwidgets)
library(dplyr)
library(beepr)
library(manipulateWidget)
library(scales)

#####Load data samples into tables (Israel - TLV-Yafo-Ashdod data)#####
IL1996 <- read.delim("~/RAW/TLV/telaviv1996db.txt", header = FALSE)
IL1997 <- read.delim("~/RAW/TLV/telaviv1997db.txt", header = FALSE, sep = "")
IL1998 <- read.delim("~/RAW/TLV/telaviv1998db.txt", header = FALSE, sep = "")
IL1999 <- read.delim("~/RAW/TLV/telaviv.1999.db.txt", header = FALSE, sep = "")
IL2000 <- read.delim("~/RAW/TLV/telaviv2000db.txt", header = FALSE, sep = "")
IL2001 <- read.delim("~/RAW/TLV/telaviv.2001.db.txt", header = FALSE, sep = "")
IL2002 <- read.delim("~/RAW/TLV/telaviv.2002.db.txt", header = FALSE, sep = "")
IL2003 <- read.delim("~/RAW/TLV/telaviv.2003.db.txt", header = FALSE, sep = "")
IL2004 <- read.delim("~/RAW/TLV/telaviv.2004.db.txt", header = FALSE, sep = "")
IL2005 <- read.delim("~/RAW/TLV/telaviv.2005.db.txt", header = FALSE, sep = "")
IL2006 <- read.delim("~/RAW/TLV/telaviv.2006.db.txt", header = FALSE, sep = "")
IL2007 <- read.delim("~/RAW/TLV/telaviv.2007.db.txt", header = FALSE, sep = "")
IL2008 <- read.delim("~/RAW/TLV/telaviv.2008.db.txt", header = FALSE, sep = "")
IL2009 <- read.delim("~/RAW/TLV/telaviv.2009.db.txt", header = FALSE, sep = "")
IL2010 <- read.delim("~/RAW/TLV/telaviv.2010.db.txt", header = FALSE, sep = "")
IL2011 <- read.delim("~/RAW/TLV/yaffo-2011-db.txt", header = FALSE, sep = "")
IL2012 <- read.delim("~/RAW/TLV/yaffo.2012.db.txt", header = FALSE, sep = "")
IL2013 <- read.delim("~/RAW/TLV/yaffo.2013.db.txt", header = FALSE, sep = "")
IL2014 <- read.delim("~/RAW/TLV/yafo.2014.db.txt", header = FALSE, sep = "")
IL2015 <- read.delim("~/RAW/TLV/yaffo2.2015.db.txt", header = FALSE, sep = "")
IL2016 <- read.delim("~/RAW/TLV/yafo.2016.db.txt", header = FALSE, sep = "")
IL2017 <- read.delim("~/RAW/TLV/ashdod.year.2017.db.txt", header = FALSE, sep = "")
IL2018 <- read.delim("~/RAW/TLV/yafo-2018-db.txt", header = FALSE, sep = "")
IL2019 <- read.delim("~/RAW/TLV/yaffo1-2019-db.txt", header = FALSE, sep = "")
IL2020 <- read.delim("~/RAW/TLV/yafo2020-db.txt", header = FALSE, sep = "")

IL1996 <- data.frame(IL1996$V5, IL1996$V6, IL1996$V7)                                        # remove unnecessary columns
names(IL1996) <- c("V1","V2","V3")                                                        # and rename to fit other tables

#####Combine tables into one:#####
IL96to20 <- rbind(IL1996, IL1997, IL1998, IL1999, IL2000, IL2001, IL2002, IL2003, IL2004, IL2005, IL2006, IL2007, IL2008, IL2009, IL2010,
                  IL2011, IL2012, IL2013, IL2014, IL2015, IL2016, IL2017, IL2018, IL2019, IL2020)
rm(IL1996, IL1997, IL1998, IL1999, IL2000, IL2001, IL2002, IL2003, IL2004, IL2005, IL2006, IL2007, IL2008, IL2009, IL2010,
   IL2011, IL2012, IL2013, IL2014, IL2015, IL2016, IL2017, IL2018, IL2019, IL2020) # remove old datasets

#####Calculate difference and add to table#####
DiffIL96to20 <-  tail(IL96to20[3], -1) - head(IL96to20[3], -1)
DiffIL96to20 <-  rbind(c(0), DiffIL96to20)
IL96to20$SL_change <- DiffIL96to20
DiffPerCIL96to20 <-  tail(DiffIL96to20, -1) / head(IL96to20[3], -1)
DiffPerCIL96to20 <-  rbind(c(0), DiffPerCIL96to20)
IL96to20$SL_changePerC <- round(DiffPerCIL96to20, 2)*100

rm(DiffIL96to20) # remove unneeded dataset
rm(DiffPerCIL96to20) # remove unneeded dataset

headerVec <- c("date","time","sea level (m)", "change in sea level (m)", "change in sea level (%)")                 # create informative header vector
names(IL96to20) <- headerVec          # insert new header names
rm(headerVec)
IL96to20$datetime <- paste(IL96to20$date, IL96to20$time)  # combine date and time
IL96to20$datetime <- dmy_hms(IL96to20$datetime)

#####Data analysis - find min max & diff#####
maxLevel <- max(IL96to20$`sea level (m)`)
minLevel <- min(IL96to20$`sea level (m)`)
levelDiff <- maxLevel - minLevel
maxChange <- max(IL96to20$`change in sea level (m)`)

IL96to20[which(IL96to20$`sea level (m)` == maxLevel),]  # display when maxLevel recorded
IL96to20[which(IL96to20$`sea level (m)` == minLevel),]  # display when minLevel recorded

changeCol <- as.matrix(IL96to20[,4])
changeCol <- as.vector(changeCol)
median(changeCol)
rm(changeCol)

# use IL96to20[1449890,] to display entire row
# or use IL96to20[1449880:1449900,] to display rows in range


#####Create html plot with dygraph######

# Then you can create the xts necessary to use dygraph
don <- xts(x = IL96to20$`sea level (m)`, order.by = IL96to20$datetime)

# Finally the plot
p <- dygraph(don) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE, colors="#D8AE5A") %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.2, hideOnMouseOut = FALSE)  %>%
  dyRoller(rollPeriod = 1)

# save the widget
# saveWidget(p, file="~/dygraphs318.html")

p



#####Create plot with ggplot2######
# 
# p <- ggplot(IL96to20, aes(x = datetime, y = `change in sea level (m)`)) +
#   geom_line() + scale_x_date(date_labels = "%B %Y") +
#   xlab("") +
#   theme_ipsum() +
#   theme(axis.text.x=element_text(angle=45, hjust=1)) 
# p






#####Subsetting winters#####
#w2010
dateStart <- (dmy("1/10/2009"))
dateStart <- which(IL96to20$datetime == dateStart)
dateEnd <- (dmy("1/3/2010"))
dateEnd <- which(IL96to20$datetime == dateEnd)
WINTER2010 <- IL96to20[dateStart:dateEnd,]

#w2011
dateStart <- (dmy("1/10/2010"))
dateStart <- which(IL96to20$datetime == dateStart)
dateEnd <- (dmy("1/1/2011"))
dateEnd <- which(IL96to20$datetime == dateEnd)
WINTER2011 <- IL96to20[dateStart:dateEnd,]

#w2012
dateStart <- (dmy("1/10/2011"))
dateStart <- which(IL96to20$datetime == dateStart)
dateEnd <- (dmy("1/3/2012"))
dateEnd <- which(IL96to20$datetime == dateEnd)
WINTER2012 <- IL96to20[dateStart:dateEnd,]

#w2013
dateStart <- (dmy("1/10/2012"))
dateStart <- which(IL96to20$datetime == dateStart)
dateEnd <- (dmy("1/3/2013"))
dateEnd <- which(IL96to20$datetime == dateEnd)
WINTER2013 <- IL96to20[dateStart:dateEnd,]

#w2014
dateStart <- (dmy("1/10/2013"))
dateStart <- which(IL96to20$datetime == dateStart)
dateEnd <- (dmy("1/3/2014"))
dateEnd <- which(IL96to20$datetime == dateEnd)
WINTER2014 <- IL96to20[dateStart:dateEnd,]

#w2015
dateStart <- (dmy("1/10/2014"))
dateStart <- which(IL96to20$datetime == dateStart)
dateEnd <- (dmy("1/3/2015"))
dateEnd <- which(IL96to20$datetime == dateEnd)
WINTER2015 <- IL96to20[dateStart:dateEnd,]




#####Create SEA LEVEL plot with dygraph 96-20 ######

# Then you can create the xts necessary to use dygraph
don <- xts(x = IL96to20$`sea level (m)`, order.by = IL96to20$datetime)
don2 <- xts(x = IL96to20$`change in sea level (m)`, order.by = IL96to20$datetime)
g96to20 <- cbind(don,don2)
# Finally the plot
p96to20 <- dygraph(g96to20, main = "Sea Level 1996 - 2020", ylab = "Sea level (m)") %>%
  dySeries("don", label = "Sea level (m)", color = "blue") %>%
  dySeries("V3", label = "Change in Sea level (m)", color = "red") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE) %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.85, hideOnMouseOut = TRUE)  %>%
  dyRoller(rollPeriod = 1)

# save the widget
saveWidget(p96to20, file="~/dygraphsp96to20.html")
beep()
# p




#####Create SEA LEVEL plot with dygraph All of 2013 ######
#subsetting 2013
dateStart <- (dmy("1/1/2013"))
dateStart <- which(IL96to20$datetime == dateStart)
dateEnd <- (dmy("1/1/2014"))
dateEnd <- which(IL96to20$datetime == dateEnd)
ALL2013 <- IL96to20[dateStart:dateEnd,]
# Then you can create the xts necessary to use dygraph
don <- xts(x = ALL2013$`sea level (m)`, order.by = ALL2013$datetime)
don2 <- xts(x = ALL2013$`change in sea level (m)`, order.by = ALL2013$datetime)
gall2013 <- cbind(don,don2)
# Finally the plot
pall2013 <- dygraph(gall2013, main = "Sea Level 2013", ylab = "Sea level (m)") %>%
  dySeries("don", label = "Sea level (m)", color = "blue") %>%
  dySeries("V3", label = "Change in Sea level (m)", color = "red") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE) %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.85, hideOnMouseOut = TRUE)  %>%
  dyRoller(rollPeriod = 1)

# save the widget
saveWidget(pall2013, file="~/dygraphsgAll2013.html")
beep()
# p




#####Create CHANGE plot with dygraph 96-20 ######

# Then you can create the xts necessary to use dygraph
don <- xts(x = IL96to20$`change in sea level (m)`, order.by = IL96to20$datetime)

# Finally the plot
p <- dygraph(don, main = "The Change in Sea Level 1996 - 2020", ylab = "Change in Sea level (m)") %>%
  dySeries("V3", label = "Change in Sea level (m)") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE, colors="red") %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.2, hideOnMouseOut = FALSE)  %>%
  dyRoller(rollPeriod = 1) 

# save the widget
saveWidget(p, file="~/dygraphsChange.html")
beep()
# p



#####Create CHANGE plot with dygraph w2010 ######

# Then you can create the xts necessary to use dygraph
don <- xts(x = WINTER2010$`change in sea level (m)`, order.by = WINTER2010$datetime)
don2 <- xts(x = WINTER2010$`sea level (m)`, order.by = WINTER2010$datetime)
g2010 <- cbind(don,don2)
# Finally the plot
pw2010 <- dygraph(g2010, main = "The Change in Sea Level Winter 2009-2010", ylab = "Change in Sea level (m)") %>%
  dySeries("don2", label = "Sea level (m)", color = "blue") %>%
  dySeries("V3", label = "Change in Sea level (m)", color = "red") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE) %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.85, hideOnMouseOut = TRUE)  %>%
  dyRoller(rollPeriod = 1) 

# save the widget
saveWidget(pw2010, file="~/dygraphsChangeW2010.html")
beep()
# p


#####Create CHANGE plot with dygraph w2011 ######

# Then you can create the xts necessary to use dygraph
don <- xts(x = WINTER2011$`change in sea level (m)`, order.by = WINTER2011$datetime)
don2 <- xts(x = WINTER2011$`sea level (m)`, order.by = WINTER2011$datetime)
g2011 <- cbind(don,don2)
# Finally the plot
pw2011 <- dygraph(g2011, main = "The Change in Sea Level Winter 2010-2011", ylab = "Change in Sea level (m)") %>%
  dySeries("don2", label = "Sea level (m)", color = "blue") %>%
  dySeries("V3", label = "Change in Sea level (m)", color = "red") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE) %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.85, hideOnMouseOut = TRUE)  %>%
  dyRoller(rollPeriod = 1) 

# save the widget
saveWidget(pw2011, file="~/dygraphsChangeW2011.html")
beep()
# p

#####Create CHANGE plot with dygraph w2012 ######

# Then you can create the xts necessary to use dygraph
don <- xts(x = WINTER2012$`change in sea level (m)`, order.by = WINTER2012$datetime)
don2 <- xts(x = WINTER2012$`sea level (m)`, order.by = WINTER2012$datetime)
g2012 <- cbind(don,don2)
# Finally the plot
pw2012 <- dygraph(g2012, main = "The Change in Sea Level Winter 2011-2012", ylab = "Change in Sea level (m)") %>%
  dySeries("don2", label = "Sea level (m)", color = "blue") %>%
  dySeries("V3", label = "Change in Sea level (m)", color = "red") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE) %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.85, hideOnMouseOut = TRUE)  %>%
  dyRoller(rollPeriod = 1) 

# save the widget
saveWidget(pw2012, file="~/dygraphsChangeW2012.html")
beep()
# p

#####Create CHANGE plot with dygraph w2013 ######

# Then you can create the xts necessary to use dygraph
don <- xts(x = WINTER2013$`change in sea level (m)`, order.by = WINTER2013$datetime)
don2 <- xts(x = WINTER2013$`sea level (m)`, order.by = WINTER2013$datetime)
g2013 <- cbind(don,don2)
# Finally the plot
pw2013 <- dygraph(g2013, main = "The Change in Sea Level Winter 2012-2013", ylab = "Change in Sea level (m)") %>%
  dySeries("don2", label = "Sea level (m)", color = "blue") %>%
  dySeries("V3", label = "Change in Sea level (m)", color = "red") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE) %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.85, hideOnMouseOut = TRUE)  %>%
  dyRoller(rollPeriod = 1) 

# save the widget
saveWidget(pw2013, file="~/dygraphsChangeW2013.html")
beep()
# p

#####Create CHANGE plot with dygraph w2014 ######

# Then you can create the xts necessary to use dygraph
don <- xts(x = WINTER2014$`change in sea level (m)`, order.by = WINTER2014$datetime)
don2 <- xts(x = WINTER2014$`sea level (m)`, order.by = WINTER2014$datetime)
g2014 <- cbind(don,don2)
# Finally the plot
pw2014 <- dygraph(g2014, main = "The Change in Sea Level Winter 2013-2014", ylab = "Change in Sea level (m)") %>%
  dySeries("don2", label = "Sea level (m)", color = "blue") %>%
  dySeries("V3", label = "Change in Sea level (m)", color = "red") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE) %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.85, hideOnMouseOut = TRUE)  %>%
  dyRoller(rollPeriod = 1) 

# save the widget
saveWidget(pw2014, file="~/dygraphsChangeW2014.html")
beep()
# p

#####Create CHANGE plot with dygraph w2015 ######

# Then you can create the xts necessary to use dygraph
don <- xts(x = WINTER2015$`change in sea level (m)`, order.by = WINTER2015$datetime)
don2 <- xts(x = WINTER2015$`sea level (m)`, order.by = WINTER2015$datetime)
g2015 <- cbind(don,don2)
# Finally the plot
pw2015 <- dygraph(g2015, main = "The Change in Sea Level Winter Winter 2014-2015", ylab = "Change in Sea level (m)") %>%
  dySeries("don2", label = "Sea level (m)", color = "blue") %>%
  dySeries("V3", label = "Change in Sea level (m)", color = "red") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE) %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.85, hideOnMouseOut = TRUE)  %>%
  dyRoller(rollPeriod = 1) 

# save the widget
saveWidget(pw2015, file="~/dygraphsChangeW2015.html")
beep()
# p




##### combine dygraphs and save to file
combined_pw <- combineWidgets(pw2010, pw2011, pw2012, pw2013, pw2014, pw2015)
saveWidget(combined_pw, file="~/dygraphsCombined2010-15.html")
beep()


#####TEST w2015 change percent######

# Then you can create the xts necessary to use dygraph
don <- xts(x = WINTER2015$`change in sea level (%)`, order.by = WINTER2015$datetime)
don2 <- xts(x = WINTER2015$`sea level (m)`, order.by = WINTER2015$datetime)
g2015 <- cbind(don,don2)
# Finally the plot
pw2015 <- dygraph(g2015, main = "The Change in Sea Level Winter Winter 2014-2015") %>%
  dySeries("don2", axis = 'y', label = "Sea level (m)", color = "blue") %>%
  dySeries("V3", axis = 'y2', label = "Change in Sea level (%)", color = "red") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.1, drawGrid = FALSE) %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.85, hideOnMouseOut = TRUE)  %>%
  dyRoller(rollPeriod = 1) 

# save the widget
saveWidget(pw2015, file="~/dygraphsChangeW2015.html")
beep()
# p




##### combine dygraphs and save to file
combined_pw <- combineWidgets(pw2010, pw2011, pw2012, pw2013, pw2014, pw2015)
saveWidget(combined_pw, file="~/dygraphsCombined2010-15.html")
beep()
